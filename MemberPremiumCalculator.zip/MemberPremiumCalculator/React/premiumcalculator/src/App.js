import React, { useEffect, useState } from "react";

const API_BASE = "http://localhost:5156/api/MemberPremiums";

/* --------------------
   Inline styles (single place to tweak)
   -------------------- */
const styles = {
  page: {
    fontFamily: "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
    background: "#f4f7fb",
    minHeight: "100vh",
    padding: "28px 16px",
    boxSizing: "border-box",
  },
  card: {
    maxWidth: 880,
    margin: "0 auto",
    background: "#fff",
    borderRadius: 12,
    padding: 20,
    boxShadow: "0 8px 30px rgba(29,41,55,0.06)",
  },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  title: { margin: 0, fontSize: 20, color: "#102A43" },
  sub: { color: "#526374", fontSize: 13 },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, 1fr)",
    gap: 12,
    alignItems: "start",
  },

  label: { display: "block", fontSize: 13, color: "#334E68", marginBottom: 6 },
  input: {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid #E6EEF3",
    fontSize: 14,
    outline: "none",
    boxSizing: "border-box",
  },
  select: {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid #E6EEF3",
    fontSize: 14,
  },

  actions: { display: "flex", gap: 10, marginTop: 16, alignItems: "center" },

  btn: {
    padding: "10px 14px",
    borderRadius: 8,
    fontSize: 14,
    cursor: "pointer",
    border: "none",
    boxShadow: "0 2px 8px rgba(16,42,67,0.06)",
  },
  btnPrimary: { background: "#0B79D0", color: "#fff" },
  btnSecondary: { background: "#E6EEF3", color: "#0B79D0" },
  btnDisabled: { background: "#F0F4F8", color: "#9AA8B3", cursor: "not-allowed" },

  resultBox: { marginTop: 16, padding: 14, borderRadius: 10, background: "#F1F9EE", color: "#0B6B2B", fontWeight: 600 },
  infoBox: { marginTop: 8, padding: 10, borderRadius: 8, background: "#F8FBFF", border: "1px solid #E6F0FA", color: "#0B69D0" },
  errorBox: { marginTop: 12, padding: 10, borderRadius: 8, background: "#FFF5F5", color: "#A61B1B" },
  successBox: { marginTop: 12, padding: 10, borderRadius: 8, background: "#E9F6F1", color: "#0A6B2A" },

  small: { fontSize: 12, color: "#526374" },
  occupationMeta: { fontSize: 13, color: "#334E68", marginTop: 6 },
  spinner: { width: 16, height: 16, verticalAlign: "middle", marginRight: 8 }
};

/* Simple inline SVG spinner */
function Spinner({ style }) {
  return (
    <svg style={style} viewBox="0 0 50 50" aria-hidden="true">
      <circle cx="25" cy="25" r="20" fill="none" stroke="#0B79D0" strokeWidth="4" strokeLinecap="round" strokeDasharray="31.4 31.4">
        <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="0.9s" from="0 25 25" to="360 25 25"/>
      </circle>
    </svg>
  );
}

/* --------------------
   Component
   -------------------- */
export default function App() {
  const [occupations, setOccupations] = useState([]);
  const [loadingOcc, setLoadingOcc] = useState(true);
  const [occError, setOccError] = useState(null);

  const [form, setForm] = useState({ name: "", ageNextBirthday: "", dob: "", occupation: "", deathSumInsured: "" });

  const [monthly, setMonthly] = useState(null);
  const [calcError, setCalcError] = useState(null);
  const [canSave, setCanSave] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState(null);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoadingOcc(true);
      setOccError(null);
      try {
        const res = await fetch(`${API_BASE}/OccupationList`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (!mounted) return;
        setOccupations(data || []);
        if (data && data.length > 0) setForm(f => ({ ...f, occupation: data[0].name }));
      } catch (err) {
        console.error(err);
        if (!mounted) return;
        setOccError("Could not load occupations. Check backend.");
      } finally {
        if (mounted) setLoadingOcc(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, []);

  function onChange(e) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // clear previous calculation if inputs change
    setMonthly(null);
    setCanSave(false);
    setCalcError(null);
    setSaveResult(null);
  }

  async function handleCalculate() {
    setCalcError(null);
    setMonthly(null);
    setCanSave(false);
    setSaveResult(null);

    // client-side basic validation
    if (!form.name || !form.ageNextBirthday || !form.dob || !form.occupation || !form.deathSumInsured) {
      setCalcError("All fields are mandatory to calculate.");
      return;
    }

    const payload = {
      name: form.name,
      ageNextBirthday: parseInt(form.ageNextBirthday, 10),
      dob: form.dob,
      occupation: form.occupation,
      deathSumInsured: parseFloat(form.deathSumInsured)
    };

    try {
      // show small loader inside button by toggling temporary state
      const res = await fetch(`${API_BASE}/CalculateMonthlyPremium`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || `Server error (${res.status})`);
      setMonthly(Number(data.monthlyPremium));
      setCanSave(true);
      setCalcError(null);
    } catch (err) {
      console.error(err);
      setCalcError(err.message || "Calculation failed.");
    }
  }

  async function handleSave() {
    if (!canSave || saving) return;
    setSaving(true);
    setSaveResult(null);
    setCalcError(null);
    try {
      const res = await fetch(`${API_BASE}/SavePremium`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          ageNextBirthday: parseInt(form.ageNextBirthday, 10),
          dob: form.dob,
          occupation: form.occupation,
          deathSumInsured: parseFloat(form.deathSumInsured)
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || `Server error (${res.status})`);
      setSaveResult({ success: true, id: data.id, monthly: Number(data.monthlyPremium) });
      setCanSave(false);
    } catch (err) {
      console.error(err);
      setSaveResult({ success: false, message: err.message || "Save failed" });
    } finally {
      setSaving(false);
    }
  }

  const selectedOcc = occupations.find(o => o.name === form.occupation);

  return (
    <div style={styles.page}>
      <div style={styles.card} role="region" aria-label="Member Premium Calculator">
        <div style={styles.header}>
          <div>
            <h2 style={styles.title}>Member Premium Calculator</h2>
          </div>
        </div>

        {loadingOcc ? (
          <div style={{ textAlign: "center", padding: 28 }}>
            <Spinner style={styles.spinner} /> Loading occupations...
          </div>
        ) : occError ? (
          <div style={styles.errorBox}>{occError}</div>
        ) : (
          <>
            <div style={styles.grid}>
              <div>
                <label style={styles.label}>Name</label>
                <input name="name" aria-label="Member name" style={styles.input} value={form.name} onChange={onChange} />
              </div>

              <div>
                <label style={styles.label}>Age Next Birthday</label>
                <input name="ageNextBirthday" aria-label="Age next birthday" style={styles.input} value={form.ageNextBirthday} onChange={onChange} type="number" min="0" />
              </div>

              <div>
                <label style={styles.label}>Date of Birth (MM/YYYY)</label>
                <input name="dob" aria-label="Date of birth" style={styles.input} value={form.dob} onChange={onChange} placeholder="08/1993" />
                <div style={styles.small}>Format: MM/YYYY</div>
              </div>

              <div>
                <label style={styles.label}>Occupation</label>
                <select name="occupation" aria-label="Occupation" style={styles.select} value={form.occupation} onChange={onChange}>
                  {occupations.map(o => <option key={o.name} value={o.name}>{o.name} — {o.rating}</option>)}
                </select>

                {selectedOcc && (
                  <div style={styles.occupationMeta}>
                    Rating: <strong>{selectedOcc.rating}</strong> &nbsp; • &nbsp;
                    Factor: <strong>{selectedOcc.factor}</strong>
                  </div>
                )}
              </div>

              <div>
                <label style={styles.label}>Death — Sum Insured</label>
                <input name="deathSumInsured" aria-label="Death sum insured" style={styles.input} value={form.deathSumInsured} onChange={onChange} type="number" />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6 }}>
                  <button
                    onClick={handleCalculate}
                    style={{ ...styles.btn, ...styles.btnPrimary }}
                    aria-label="Calculate premium"
                  >
                    <Spinner style={{ ...styles.spinner, display: calcError ? "none" : "inline-block" }} /> Calculate
                  </button>

                  <button
                    onClick={handleSave}
                    disabled={!canSave || saving}
                    aria-disabled={!canSave || saving}
                    style={{
                      ...styles.btn,
                      ...(canSave ? styles.btnSecondary : styles.btnDisabled),
                      ...(saving ? { opacity: 0.9 } : {})
                    }}
                    aria-label="Save premium"
                  >
                    {saving ? (<><Spinner style={styles.spinner} /> Saving...</>) : "Save"}
                  </button>

                  <div style={{ marginLeft: 12 }}>
                    {!canSave ? <span style={styles.small}>Calculate to enable Save</span> : <span style={{ color: "#0B6B2B", fontWeight: 600 }}>Ready to save</span>}
                  </div>
                </div>
              </div>
            </div>

            {/* result / messages */}
            <div>
              {calcError && <div style={styles.errorBox}> {calcError}</div>}

              {monthly !== null && (
                <div style={styles.resultBox}> Monthly Premium (server): ₹{Number(monthly).toFixed(2)}</div>
              )}

              {saveResult && saveResult.success && (
                <div style={styles.successBox}> Saved (ID: {saveResult.id}) — server monthly: ₹{saveResult.monthly.toFixed(2)}</div>
              )}

              {saveResult && !saveResult.success && (
                <div style={styles.errorBox}> Save failed: {saveResult.message}</div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
