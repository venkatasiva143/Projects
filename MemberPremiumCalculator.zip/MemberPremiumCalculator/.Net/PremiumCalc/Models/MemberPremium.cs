﻿using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class MemberPremium
    {
        public int Id { get; set; }
        [Required] public string MemberName { get; set; }
        public DateTime Dob { get; set; }
        public int AgeNextBirthday { get; set; }
        public string Occupation { get; set; }
        public string OccupationRating { get; set; }
        public decimal OccupationFactor { get; set; }
        public decimal DeathSumInsured { get; set; }
        public decimal CalculatedMonthlyPremium { get; set; }
        public DateTime CalculatedAt { get; set; }
    }
}
