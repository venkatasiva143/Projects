﻿namespace PremiumCalc.Utility
{
    public static class Helper
    {
        public static DateTime ParseDob(string mmYYYY)
        {
            if (string.IsNullOrWhiteSpace(mmYYYY))
                throw new ArgumentException("Date of Birth is required.", nameof(mmYYYY));

            var parts = mmYYYY.Trim().Replace("-", "/").Split('/');
            if (parts.Length != 2)
                throw new FormatException("Date of Birth must be in MM/YYYY format.");

            if (!int.TryParse(parts[0], out int month) || month < 1 || month > 12)
                throw new FormatException("Invalid month in Date of Birth. Use MM/YYYY.");

            if (!int.TryParse(parts[1], out int year) || year < 1900 || year > DateTime.UtcNow.Year)
                throw new FormatException("Invalid year in Date of Birth. Use MM/YYYY.");

            return new DateTime(year, month, 1);
        }
    }
}
