﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PremiumCalc.Controllers
{
    [ApiController]
    [EnableCors()]
    [Route("api/[controller]")]
    public class MemberPremiumsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public MemberPremiumsController(AppDbContext context)
        {
            _context = context;
        }

        // ----------------------------
        // 1. Get Occupation List
        // ----------------------------
        [HttpGet("OccupationList")]
        public IActionResult GetOccupationList()
        {
            var list = OccupationMap.GetAll()
                .Select(o => new { o.Name, o.Rating, o.Factor })
                .ToList();
            return Ok(list);
        }

        // ----------------------------
        // 2. Calculate Premium (no save)
        // ----------------------------
        [HttpPost("CalculateMonthlyPremium")]
        public IActionResult CalculateMonthlyPremium([FromBody] PremiumRequest req)
        {
            if (!ValidateInput(req, out string errorMessage))
                return BadRequest(new { message = errorMessage });

            var occ = OccupationMap.Get(req.Occupation);
            if (occ == null)
                return BadRequest(new { message = "Unknown occupation." });

            // Parse DOB
            DateTime dob;
            try
            {
                dob = Utility.Helper.ParseDob(req.Dob);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }

            var monthly = CalculatePremium(req.DeathSumInsured, occ.Factor, req.AgeNextBirthday);
            return Ok(new
            {
                monthlyPremium = decimal.Round(monthly, 2),
                occupationRating = occ.Rating,
                occupationFactor = occ.Factor
            });
        }

        // ----------------------------
        // 3. Save Premium (with DB save)
        // ----------------------------
        [HttpPost("SavePremium")]
        public async Task<IActionResult> SavePremium([FromBody] PremiumRequest req)
        {
            if (!ValidateInput(req, out string errorMessage))
                return BadRequest(new { message = errorMessage });

            var occ = OccupationMap.Get(req.Occupation);
            if (occ == null)
                return BadRequest(new { message = "Unknown occupation." });

            DateTime dob;
            try
            {
                dob = Utility.Helper.ParseDob(req.Dob);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }

            var monthly = CalculatePremium(req.DeathSumInsured, occ.Factor, req.AgeNextBirthday);

            var record = new MemberPremium
            {
                MemberName = req.Name,
                Dob = dob,
                AgeNextBirthday = req.AgeNextBirthday,
                Occupation = occ.Name,
                OccupationRating = occ.Rating,
                OccupationFactor = occ.Factor,
                DeathSumInsured = req.DeathSumInsured,
                CalculatedMonthlyPremium = monthly,
                CalculatedAt = DateTime.UtcNow
            };

            _context.MemberPremiums.Add(record);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                id = record.Id,
                monthlyPremium = decimal.Round(monthly, 2),
                message = "Premium saved successfully."
            });
        }

        // ----------------------------
        // Shared helpers
        // ----------------------------
        private static bool ValidateInput(PremiumRequest req, out string error)
        {
            error = string.Empty;
            if (req == null)
            {
                error = "Invalid request.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(req.Name) ||
                string.IsNullOrWhiteSpace(req.Dob) ||
                string.IsNullOrWhiteSpace(req.Occupation) ||
                req.AgeNextBirthday <= 0 ||
                req.DeathSumInsured <= 0)
            {
                error = "All input fields are mandatory and must be valid.";
                return false;
            }
            return true;
        }

        private static decimal CalculatePremium(decimal deathSumInsured, decimal factor, int age)
        {
            // Formula: Death Premium = (Death Cover amount * Occupation Rating Factor * Age) /1000 * 12
            var annual = (deathSumInsured * factor * age) / (1000m * 12m);
            var monthly = annual / 12m; // monthly
            return decimal.Round(monthly, 4, MidpointRounding.AwayFromZero);
        }
    }

    // ------------- Models -----------------
    public record PremiumRequest(string Name, int AgeNextBirthday, string Dob, string Occupation, decimal DeathSumInsured);

    // ------------- Occupation Lookup -----------------
    public record OccupationInfo(string Name, string Rating, decimal Factor);

    public static class OccupationMap
    {
        private static readonly List<OccupationInfo> data = new()
        {
            new OccupationInfo("Cleaner", "Light Manual", 11.5m),
            new OccupationInfo("Doctor", "Professional", 1.5m),
            new OccupationInfo("Author", "White Collar", 2.25m),
            new OccupationInfo("Farmer", "Heavy Manual", 31.75m),
            new OccupationInfo("Mechanic", "Heavy Manual", 31.75m),
            new OccupationInfo("Florist", "Light Manual", 11.5m),
            new OccupationInfo("Other", "Heavy Manual", 31.75m)
        };

        public static OccupationInfo? Get(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return null;
            return data.FirstOrDefault(d => d.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public static IEnumerable<OccupationInfo> GetAll() => data;
    }
}
